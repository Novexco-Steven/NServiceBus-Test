﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Core.Messages
{

    public class Invoice : Base.MessageBase
    {
    }
}
