using System;
using NServiceBus;

namespace Shared.Core.Messages
{
    public class Order : Base.MessageBase
    {
    }
}